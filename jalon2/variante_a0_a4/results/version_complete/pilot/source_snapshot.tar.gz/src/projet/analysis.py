"""Synthèse des sorties sauvegardées ; aucune nouvelle recherche."""

from __future__ import annotations

from collections import defaultdict
import csv
import json
from itertools import combinations
from pathlib import Path
import statistics

import numpy as np

from .data import write_json


def quantile(values, p):
    return float(np.quantile(values, p))


def csv_table(path, rows):
    if not rows:
        return
    with path.open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def analyze(input_dir, output_dir):
    import matplotlib
    matplotlib.use("Agg")
    from matplotlib import pyplot as plt

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    all_runs = [json.loads(p.read_text()) for p in sorted(Path(input_dir).rglob("result.json"))]
    runs = [r for r in all_runs if r.get("completed") and r.get("status") == "ok"
            and r.get("solution") and r["method"] != "single"]
    rows, grouped, strata, paired, by_instance = [], defaultdict(list), defaultdict(list), defaultdict(dict), defaultdict(list)
    for run in runs:
        d, s, cfg = run["dataset"], run["solution"], run["identity"]["config"]
        method = f"{run['method']}-{run['initializer']}"
        budget = cfg["milp_seconds"] if run["method"] == "MILP" else cfg["seconds"]
        validated_trace = [t for t in run["trace"] if t["event"] != "milp_incumbent_unvalidated"]
        row = {"run_id": run["run_id"], "dataset_path": d["path"], "dataset_hash": d["hash"],
               "type": d.get("type"), "configuration": d.get("configuration"),
               "noise": d.get("announced_noise"), "ratio": d.get("announced_ratio"),
               "N": d["N"], "m": d["m"], "C": d["C"], "method": method, "seed": run["seed"],
               "budget": budget, "LG": s["LG"], "error_rate": s["error_rate"],
               "wall_time": run["wall_time"], "group0": s["group_sizes"][0], "group1": s["group_sizes"][1],
               "wpb_calls": run["counters"].get("wpb_calls", 0), "stop_reason": run["stop_reason"],
               "overrun_count": len(run["overruns"])}
        for target in (0, .05, .10):
            row[f"time_to_rate_{target:g}"] = next((t["time"] for t in validated_trace if t["best_LG"]/d["N"] <= target), None)
        rows.append(row)
        grouped[method, budget].append(row)
        strata[method, budget, d.get("type"), d.get("configuration"), d.get("announced_noise"), d.get("announced_ratio")].append(row)
        by_instance[d["path"], method, budget].append(row)
        pair_key = (d["hash"], run["identity"]["problem_hash"], run["seed"], budget)
        if method in paired[pair_key]:
            raise ValueError("Plusieurs configurations pour un même appariement : analyser les campagnes séparément.")
        paired[pair_key][method] = row

    def summary(items):
        rates = [r["error_rate"] for r in items]
        return {"runs": len(items), "median_error_rate": statistics.median(rates),
                "q25": quantile(rates, .25), "q75": quantile(rates, .75),
                "best_error_rate": min(rates), "zero_frequency": sum(v == 0 for v in rates)/len(rates),
                "median_wall_time": statistics.median(r["wall_time"] for r in items)}

    summaries = [{"method": method, "budget": budget, **summary(items)}
                 for (method, budget), items in sorted(grouped.items())]
    stratified = [{"method": k[0], "budget": k[1], "type": k[2], "configuration": k[3],
                   "noise": k[4], "ratio": k[5], **summary(items)} for k, items in sorted(strata.items(), key=lambda kv: str(kv[0]))]
    differences = []
    for key, methods in paired.items():
        for baseline, method in combinations(sorted(methods), 2):
            differences.append({"dataset_hash": key[0], "seed": key[2], "budget": key[3],
                                "method": method, "baseline": baseline,
                                "error_rate_difference": methods[method]["error_rate"]-methods[baseline]["error_rate"]})
    instance_summaries = [{"dataset_path": key[0], "method": key[1], "budget": key[2], **summary(items)}
                          for key, items in sorted(by_instance.items())]
    csv_table(output / "runs.csv", rows)
    csv_table(output / "summary.csv", summaries)
    csv_table(output / "stratified.csv", stratified)
    csv_table(output / "paired_differences.csv", differences)
    csv_table(output / "instance_summary.csv", instance_summaries)
    report = {"total_results": len(all_runs), "valid_two_model_runs": len(runs),
              "statuses": {status: sum(r.get("status") == status for r in all_runs)
                           for status in sorted({r.get("status", "unknown") for r in all_runs})},
              "summary": summaries, "stratified": stratified,
              "notes": ["Les répétitions mesurent l'aléa algorithmique sur les CSV fournis.",
                        "Les bornes MILP concernent uniquement la formulation à marge.",
                        "Les exécutions invalides et sans solution sont exclues des métriques de qualité.",
                        "Les courbes temporelles agrègent les solutions disponibles ; anytime.csv donne leur couverture."]}
    write_json(output / "summary.json", report)
    if not rows:
        return report
    labels = [f"{method} ({budget:g}s)" for method, budget in sorted(grouped)]
    fig, ax = plt.subplots(figsize=(max(8, len(labels)*1.2), 4.5), layout="constrained")
    ax.boxplot([[r["error_rate"] for r in grouped[key]] for key in sorted(grouped)], tick_labels=labels)
    ax.set_ylabel("LG / N")
    ax.tick_params(axis="x", rotation=25)
    ax.set_title("Erreurs finales et variabilité sur les instances fournies")
    fig.savefig(output / "final_quality.png", dpi=160)
    plt.close(fig)
    fig, ax = plt.subplots(figsize=(9, 5), layout="constrained")
    anytime = []
    for method, budget in sorted(grouped):
        grid = np.linspace(0, max(budget, max(r["wall_time"] for r in grouped[method, budget])), 101)
        curves = []
        for run in runs:
            if f"{run['method']}-{run['initializer']}" != method:
                continue
            cfg = run["identity"]["config"]
            actual_budget = cfg["milp_seconds"] if run["method"] == "MILP" else cfg["seconds"]
            if actual_budget != budget:
                continue
            trace = [t for t in run["trace"] if t["event"] != "milp_incumbent_unvalidated"]
            curves.append([next((t["best_LG"]/run["dataset"]["N"] for t in reversed(trace) if t["time"] <= moment), np.nan)
                           for moment in grid])
        # Ne pas remplir artificiellement le temps avant la première solution.
        medians = [float(np.median(valid)) if len(valid := np.array(column)[np.isfinite(column)]) else np.nan
                   for column in zip(*curves)]
        for moment, column, median in zip(grid, zip(*curves), medians):
            anytime.append({"method": method, "budget": budget, "time": float(moment),
                            "available_runs": int(np.isfinite(column).sum()), "total_runs": len(curves),
                            "median_best_error_rate": float(median) if np.isfinite(median) else None})
        ax.step(grid, medians, where="post", label=f"{method} ({budget:g}s)")
    ax.set(xlabel="Temps total (s)", ylabel="Médiane du meilleur LG / N", title="Qualité en fonction du temps")
    ax.legend(fontsize=8)
    fig.savefig(output / "quality_time.png", dpi=160)
    plt.close(fig)
    csv_table(output / "anytime.csv", anytime)
    fig, axes = plt.subplots(2, 2, figsize=(12, 8), layout="constrained")
    for ax, factor in zip(axes.flat, ("type", "configuration", "noise", "ratio")):
        levels = sorted({str(r[factor]) for r in rows})
        for method, budget in sorted(grouped):
            rates = [[r["error_rate"] for r in grouped[method, budget] if str(r[factor]) == level] for level in levels]
            ax.plot(levels, [statistics.median(v) if v else np.nan for v in rates], marker="o", label=f"{method} ({budget:g}s)")
        ax.set(title=factor, ylabel="Médiane LG / N")
    axes[0, 0].legend(fontsize=7)
    fig.savefig(output / "factors.png", dpi=160)
    plt.close(fig)
    return report
